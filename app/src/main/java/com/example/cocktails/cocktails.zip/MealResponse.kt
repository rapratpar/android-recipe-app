package com.example.cocktails

data class MealResponse(
    val meals: List<Meal>
)