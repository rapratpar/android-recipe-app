package com.example.cocktails


import androidx.compose.runtime.Composable
import androidx.navigation.compose.*

@Composable
fun App(viewModel: MealViewModel) {
    val navController = rememberNavController()

    NavHost(navController, startDestination = "main") {
        composable("main") {
            MainScreen(navController, viewModel)
        }
        composable("details/{mealId}") { backStackEntry ->
            val id = backStackEntry.arguments?.getString("mealId") ?: ""
            RecipeDetailScreen(mealId = id, viewModel = viewModel)
        }
    }
}