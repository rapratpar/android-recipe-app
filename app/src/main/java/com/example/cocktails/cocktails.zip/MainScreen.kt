package com.example.cocktails

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.outlined.Save
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter

@Composable
fun MainScreen(navController: NavController, viewModel: MealViewModel) {
    val meals by viewModel.meals.collectAsState()
    var search by remember { mutableStateOf("") }
    var selectedScreen by remember { mutableStateOf("Wszystkie") }
    var favoriteMeals by remember { mutableStateOf(emptyList<MealEntity>()) }
    var offlineMeals by remember { mutableStateOf(emptyList<MealEntity>()) }

    // Załaduj dane do ulubionych i offline
    LaunchedEffect(Unit) {
        viewModel.getFavoriteMeals { favoriteMeals = it }
        viewModel.getOfflineMeals { offlineMeals = it }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
            OutlinedTextField(
                value = search,
                onValueChange = {
                    search = it
                    if (it.isEmpty()) viewModel.loadRandomMeals()
                    else viewModel.search(it)
                },
                label = { Text("Szukaj przepisu") },
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.width(8.dp))

            var expanded by remember { mutableStateOf(false) }
            Box {
                Button(onClick = { expanded = true }) {
                    Text(selectedScreen)
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    DropdownMenuItem(onClick = {
                        selectedScreen = "Wszystkie"
                        expanded = false
                    }) { Text("Wszystkie") }
                    DropdownMenuItem(onClick = {
                        selectedScreen = "Ulubione"
                        expanded = false
                    }) { Text("Ulubione") }
                    DropdownMenuItem(onClick = {
                        selectedScreen = "Zapisane"
                        expanded = false
                    }) { Text("Zapisane") }
                }
            }
        }

        when (selectedScreen) {
            "Wszystkie" -> MealList(meals.map {
                MealEntity(
                    id = it.idMeal,
                    name = it.strMeal,
                    thumbnail = it.strMealThumb,
                    instructions = it.strInstructions,
                    isFavorite = favoriteMeals.any { fav -> fav.id == it.idMeal },
                    isOffline = offlineMeals.any { off -> off.id == it.idMeal }
                )
            }, navController)

            "Ulubione" -> MealList(favoriteMeals, navController)

            "Zapisane" -> MealList(offlineMeals, navController)
        }
    }
}

@Composable
fun MealList(meals: List<MealEntity>, navController: NavController) {
    LazyColumn {
        items(meals) { meal ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .clickable {
                        navController.navigate("details/${meal.id}")
                    },
                elevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .padding(8.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row {
                        Image(
                            painter = rememberAsyncImagePainter(meal.thumbnail),
                            contentDescription = meal.name,
                            modifier = Modifier.size(80.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(meal.name, style = MaterialTheme.typography.h6)
                    }
                    Row {
                        Icon(
                            imageVector = if (meal.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = "Ulubione",
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Icon(
                            imageVector = if (meal.isOffline) Icons.Filled.Save else Icons.Outlined.Save,
                            contentDescription = "Zapisane"
                        )
                    }
                }
            }
        }
    }
}
