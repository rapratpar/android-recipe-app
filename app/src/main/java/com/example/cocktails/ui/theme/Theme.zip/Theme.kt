package com.example.cocktails.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Definicje kolorów czarno-pomarańczowych
private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFFF9800),         // Pomarańczowy
    onPrimary = Color.Black,
    secondary = Color(0xFFDD7B00),       // Ciemniejszy pomarańczowy
    background = Color(0xFF121212),      // Czarne tło
    surface = Color(0xFF1E1E1E),         // Ciemna powierzchnia
    onBackground = Color.White,
    onSurface = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFFFF9800),
    onPrimary = Color.White,
    secondary = Color(0xFFDD7B00),
    background = Color(0xFFFFFFFF),
    surface = Color(0xFFF5F5F5),
    onBackground = Color.Black,
    onSurface = Color.Black
)

@Composable
fun CocktailsTheme(
    darkTheme: Boolean = true, // Wymuszenie ciemnego motywu
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}